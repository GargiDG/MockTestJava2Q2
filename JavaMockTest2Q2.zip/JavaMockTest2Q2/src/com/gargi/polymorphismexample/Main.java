package com.gargi.polymorphismexample;

public class Main {
    public static void main(String[] args) {
        ShapeCalculator shapeCalculator = new ShapeCalculator();

        Rectangle rectangle = new Rectangle(5, 10);
        Circle circle = new Circle(3);
        Triangle triangle = new Triangle(4, 6);

        System.out.print("The area of the rectangle is : ");
        shapeCalculator.printArea(rectangle);
        System.out.print("The area of the circle is : ");
        shapeCalculator.printArea(circle);
        System.out.print("The area of the triangle is : ");
        shapeCalculator.printArea(triangle);
    }
}


