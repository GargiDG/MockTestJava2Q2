package com.gargi.polymorphismexample;

abstract class Shape {
    public abstract double calculateArea();
}