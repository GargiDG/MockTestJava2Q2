package com.gargi.polymorphismexample;

public class ShapeCalculator {
    public void printArea(Shape shape) {
        double area = shape.calculateArea();
        System.out.println( area);
    }
}

